﻿namespace LogicaDeProgramacao
{
    public interface IExercicio
    {
        bool VerificarResposta();
    }
}
